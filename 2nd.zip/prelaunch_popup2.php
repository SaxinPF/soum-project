﻿<div class="modal-content">
    <div class="modal-header" style="position:relative">
      <span class="close" onclick="close_2()">&times;</span>
      <h2 style="text-align:center;font-size:24px;"><strong>Pre-launch Offers</strong></h2>
      <img src="images/shadow.jpg" style="width:100%;float:left;position: absolute;bottom: -16px;left: 0;">
    </div>
    <div class="modal-body" style="width:100%;float:left;background:#fff;">   

<div class="message_box">
					<!--offer Deals start-->
				<div class="column default-featured-column style-two col-md-12" id="1product-mobile" style="padding:0px;">
           			<div class="col-md-12" style="text-align:center;padding:0px;"><img src="images/prelaunch-offer-img3.jpg" style="width:100%;height:250px;padding:0px;"/></div>
           			<div class="col-md-12" style="text-align:center;padding:10px;">
						<img src="images/prelaunch-offer-img2.jpg" style="width:100%;height:auto;"/>
	                </div>
                <!--offer Deals end-->
                <div style="width:100%;float:left;margin-top:15px;">
               		<a href="contact_preLaunch.php?preid=<?=$row['pre_id'];?>" class="theme-btn btn-style-four btn-sm bg-2" style="font-style: normal;border:2px solid#da200b !Important;width:95%;margin:auto;text-align: center;float: none;margin-left:15px;margin-bottom:15px;">I am 
					Interested</a>
               		<a href="prelaunch_dtl.php" class="theme-btn btn-style-four btn-sm bg-2" style="font-style: normal;border:2px solid#da200b !Important;width:95%;margin:auto;text-align: center;float: none;margin-left: 15px;">
					More Pre Launch Offers </a>&nbsp;</div>
				</div>
    </div>
  </div>
