<link rel="stylesheet" href="styles/plugins/select2.css">
<link rel="stylesheet" href="styles/main.min.css">
Sanjay
<hr>



			<div class="form-group">
				<select id="personSelect" style="width: 100%" data-placeholder="Select a person">
					<option></option>	<!-- empty, for placeholder -->
					<option value="1">Ram</option>
					<option value="2">Shaym</option>
					<option value="3">Mohan</option>
					<option value="4">Sohan</option>
					<option value="5">Johnson</option>
					<option value="6">Samantha</option>
					<option value="7">Estefania</option>
					<option value="8">atasha</option>
					<option value="9">icole</option>
					<option value="10">Adrian</option>
				</select>
			</div> 
											
<hr>										
Verma



											
<script src="scripts/vendors.js"></script>
<script src="scripts/plugins/select2.min.js"></script>
<script src="scripts/form-elements.init.js"></script>

