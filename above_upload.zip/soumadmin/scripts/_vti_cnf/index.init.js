vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 May 2017 06:51:19 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|admin/report2.php admin/day_by_stock.php admin/extra-dashboard.php admin/report_olx_customers.php admin/dashboard_sunil.php admin/feedback_detail.php admin/list_by_user.php admin/enquire_list.php admin/report_stock.php admin/cust_add.php admin/order_track.php admin/timeline.php admin/approv_dis.php admin/dashboard.php admin/feedback_list.php admin/order.php admin/report_services.php admin/mail_greeting.php admin/phone_detail.php admin/repair_dtl.php admin/report_activity.php admin/stock_detail.php admin/order_details.php admin/phone_detail_sunil.php admin/track_order.php admin/utilities.php admin/repair_list.php admin/report_order_summary.php admin/banner-mgmt.php admin/chat.php admin/page1.php admin/report.php admin/enq_detail.php admin/new_save.php admin/offer-mgmt.php admin/order2.php admin/update_profile.php admin/user.php admin/report_order_summary_dtl.php admin/invoice.php admin/report1.php
vti_author:SR|pawan-PC\\pawan
vti_modifiedby:SR|pawan-PC\\pawan
vti_timecreated:TR|29 May 2017 06:51:19 -0000
vti_cacheddtm:TX|29 May 2017 06:51:19 -0000
vti_filesize:IR|5864
