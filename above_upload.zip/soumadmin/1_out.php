<?php

	SESSION_START();
	$_SESSION['name']="sanjay1";
	header("location:../1_in.php");

?>