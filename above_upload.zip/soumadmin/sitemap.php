
<head>
<style type="text/css">
.auto-style1 {
	border: 1px solid #000000;
}
.auto-style2 {
	border: 1px solid #000000;
	background-color: #C0C0C0;
}
.auto-style3 {
	font-weight: normal;
}
.auto-style4 {
	font-weight: bold;
	border: 1px solid #000000;
}
.auto-style5 {
	border: 1px solid #000000;
	background-color: #FFFF00;
}
.auto-style6 {
	font-weight: bold;
	border: 1px solid #000000;
	background-color: #FFFF00;
}
</style>
</head>

<table style="width: 100%">
	<tr>
		<td class="auto-style2">Titile</td>
		<td class="auto-style2">URL</td>
		<td class="auto-style2">Ajax</td>
	</tr>
	<tr>
		<td class="auto-style1">Login</td>
		<td class="auto-style1"><a href="index.php">index.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style2"><strong>Dashboard</strong></td>
		<td class="auto-style2">&nbsp;</td>
		<td class="auto-style2">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Dashboard</td>
		<td class="auto-style1"><a href="dashboard.php">dashboard.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Left Menu</td>
		<td class="auto-style1"><a href="_left-menu.php">_left-menu.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Advertisement</td>
		<td class="auto-style1"><a href="approv_dis.php">approv_dis.php</a> |
		<a href="phone_detail.php?prod_id=52&amp;poster_id=1&amp;type=">
		phone_detail.php</a>,</td>
		<td class="auto-style1"><a href="approve.php">approve.php</a></td>
	</tr>
	<tr>
		<td class="auto-style1">Order Summery</td>
		<td class="auto-style1"><a href="order.php">order.php</a> |&nbsp;
		<a href="order2.php?prod_id=51&amp;type=2">order2.php</a> |&nbsp;
		<a href="order_details.php?order_id=8&amp;type=2">order_details.php</a>,</td>
		<td class="auto-style1"><a href="change_status.php">change_status.php</a></td>
	</tr>
	<tr>
		<td class="auto-style1">Enquiry</td>
		<td class="auto-style1"><a href="enquire_list.php">enquire_list.php</a> 
		| <a href="enq_detail.php?enq_id=12">enq_detail.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Repairing</td>
		<td class="auto-style1"><a href="repair_list.php">repair_list.php</a> |&nbsp;
		<a href="repair_dtl.php?rid=12">repair_dtl.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Track order</td>
		<td class="auto-style1"><a href="_ajax_generic-track.php">
		_ajax_generic-track.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style2"><strong>Reports</strong></td>
		<td class="auto-style2">&nbsp;</td>
		<td class="auto-style2">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Order summery</td>
		<td class="auto-style1"><a href="report_order_summary.php">
		report_order_summary.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Order summery dtl</td>
		<td class="auto-style1"><a href="report_order_summary_dtl.php">
		report_order_summary_dtl.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Stock</td>
		<td class="auto-style1"><a href="report_stock.php">report_stock.php</a> 
		|&nbsp; <a href="stock_detail.php?model=5&amp;type=2">stock_detail.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Day by Stock</td>
		<td class="auto-style1"><a href="report_stock2.php">report_stock2.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Repairing Service</td>
		<td class="auto-style1"><a href="report_services.php">
		report_services.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">OLX Customer</td>
		<td class="auto-style1"><a href="report_olx_customers.php">
		report_olx_customers.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style2"><strong>Master</strong></td>
		<td class="auto-style2">&nbsp;</td>
		<td class="auto-style2">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Brand Master</td>
		<td class="auto-style1"><a href="subcat_master.php">subcat_master.php</a> 
		|&nbsp; <a href="subcat_master_act.php">subcat_master_act.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Modal Master</td>
		<td class="auto-style1"><a href="subsubcat_master.php">
		subsubcat_master.php</a> | <a href="subsubcat_master_act.php">
		subsubcat_master_act.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Banner Master</td>
		<td class="auto-style1"><a href="banner_master.php">banner_master.php</a> 
		| <a href="banner_master_act.php">banner_master_act.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Offer Master</td>
		<td class="auto-style1"><a href="offer_master.php">offer_master.php</a> 
		| <a href="offer_save.php">offer_save.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Dealer Master</td>
		<td class="auto-style1"><a href="dealer_master.php">dealer_master.php</a> 
		|&nbsp; <a href="dealer_master_act.php">dealer_master_act.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Customer Master</td>
		<td class="auto-style1"><a href="customer_master.php">
		customer_master.php</a> | <a href="customer_master_act.php">
		customer_master_act.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style5">Subcrib Master</td>
		<td class="auto-style5"><a href="subcrib_master.php">subcrib_master.php</a>
		</td>
		<td class="auto-style5">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style5">
		<h4 class="auto-style3">Greetigs Master</h4>
		</td>
		<td class="auto-style5"><a href="greeting_master.php">
		greeting_master.php</a></td>
		<td class="auto-style5">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style5">
		<h4 class="auto-style3">ewsletter Master</h4>
		</td>
		<td class="auto-style5"><a href="newsletter_master.php">
		ewsletter_master.php</a></td>
		<td class="auto-style5">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style5">
		<div class="col-md-12">
			<div class="dash-head clearfix mb20">
				<div class="left">
					<h4 class="auto-style3">Feedback/ Contact Us Master</h4>
				</div>
			</div>
		</div>
		</td>
		<td class="auto-style5"><a href="feedback_list.php">
		feedback_list.php</a> | 
		<a href="feedback_detail.php">feedback_detail.php</a></td>
		<td class="auto-style5">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style6">
		<div class="col-md-12">
			<div class="dash-head clearfix mb20">
				<div class="left">
					<h4 class="auto-style3">Cupon Master</h4>
				</div>
			</div>
		</div>
		</td>
		<td class="auto-style5"><a href="cupon_master.php">cupon_master.php</a></td>
		<td class="auto-style5">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style4">
		<h4 class="auto-style3">Financer Master</h4>
		</td>
		<td class="auto-style1"><a href="financer_master.php">
		financer_master.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style4">
		<h4 class="auto-style3">Home Adv Master</h4>
		</td>
		<td class="auto-style1"><a href="setting_service_master.php">
		setting_service_master.php</a> | <a href="setting_service_save.php">
		setting_service_save.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style2"><strong>Chat</strong></td>
		<td class="auto-style2">&nbsp;</td>
		<td class="auto-style2">&nbsp;</td>
	</tr>
	<tr>
		<td class="auto-style1">Chat</td>
		<td class="auto-style1"><a href="chat_server.php">chat_server.php</a> |
		<a href="chat_count.php">chat_count.php</a> |&nbsp;
		<a href="chat_details.php">chat_details.php</a> |
		<a href="chat_save.php">chat_save.php</a> | <a href="chate2.php">
		chate2.php</a></td>
		<td class="auto-style1">&nbsp;</td>
	</tr>
</table>
