 <div class="clearfix"></div>
   <div class="advert">
  <div class="container">
  <h2 style="featara">Hot deals</h2>
  <div class="row">

   <div class="col-sm-4"><a href="https://www.soum.co.in/samsung-galaxy-s10-2878"><img src="/img/add1.jpg" style="padding-right: 10px;" alt=""></a></div>
   <div class="col-sm-4"><a href="https://www.soum.co.in/apple-xs-max-2856"><img src="/img/add2.jpg" style="padding-right: 10px;" alt=""></a></div>
   <div class="col-sm-4"><a href="https://www.soum.co.in/apple-xr-2877"><img src="/img/add3.jpg" style="padding-right: 10px;" alt=""></a></div>

   </div>
   </div>
   </div>
 <div class="clearfix"></div>
