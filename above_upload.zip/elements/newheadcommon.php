
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-168453932-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-168453932-1');
</script>

	<meta charset="utf-8">
		<meta name="Googlebot-News" content="noindex, nofollow">
		<meta name="googlebot" content="noindex, nofollow">
		<meta name="theme-color" content="#ff2d20">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="preload" href="../new_css/bootstrap.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
		<noscript><link rel="stylesheet" type="text/css" href="../new_css/bootstrap.min.css"></noscript>
		<link rel="stylesheet" type="text/css" href="../new_css/slick.css">
		<link rel="stylesheet" type="text/css" href="../new_css/slick-theme.css">
		<link rel="stylesheet" media="all" href="../new_css/style.css?<?= time();?>">
		<link rel="icon" type="image/x-icon" href="../new_img/favicon.png">
    <title><?php echo $layout_title; ?></title>


