<div class="clearfix"></div>
  <div class="ourservices container">
  <h2>Our Services</h2>
  <div class="row">
  <div class="col-sm-6">
       <div class="servsect"><figure><img src="img/1.png" alt=""/></figure>
          <h3>Mobile Repair <span>Tell us issue of your phone. Our experts will provide you <a href="mobile-repair-shop-jaipur.php">quick repair</a> service at reasonable cost in minimal time.</span></h3>
       </div>
  </div>
  <div class="col-sm-6">
     <div class="servsect"><figure><img src="img/2.png" alt=""/></figure>
      <h3>Buy Used Phones <span>Our website allows you to buy mobile phone of your choice irrespective of the budget. <a href="second-hand-phone-jaipur">Get Started</a></span></h3>

     </div>
  </div>
  <div class="col-sm-6">
     <div class="servsect"><figure><img src="img/3.png" alt=""/></figure>
      <h3>Sell Used Phones <span>Our website provides you a large audience which makes sure that you are able to <a href="sell_used_phone.php">sell your phone</a> at the best possible price.</span></h3>
     </div>
  </div>
  <div class="col-sm-6">
      <div class="servsect"><figure><img src="img/4.png" alt=""/></figure>
        <h3>Looking for something else? <span>Are you exactly not sure what phone you want to purchase or unaware of the problem happening in your device. No problem, Fill the form by & <a href="/tell_us.php" onclick="call_prebook()" >Clicking here</a> and we will contact you!</span></h3>
      </div>
  </div>


  </div>

  </div>
 <div class="clearfix"></div>
