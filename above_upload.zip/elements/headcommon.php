<!-- Required meta tags -->
    <meta charset="utf-8">
    <!--<meta http-equiv="Content-type" content="text/html;charset=UTF-8"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <!--  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script> -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-168453932-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-168453932-1');
</script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/custom.css" integrity="" crossorigin="">
    <link rel="stylesheet" href="css/cj_custom.css" integrity="" crossorigin="">
    <link rel="stylesheet" href="css/bootstrap.min.css" integrity="" crossorigin="">
     <!-- Owl Stylesheets -->
    <link rel="stylesheet" href="assets/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/owlcarousel/assets/owl.theme.default.min.css">


    <title><?php echo $layout_title; ?></title>
    <script src="js/jquery-3.2.1.slim.min.js" ></script>

