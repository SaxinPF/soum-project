<?php
echo phpinfo();
?>
