<html>
	<head>
		<script src="js/jquery.min.js" type="text/javascript"></script>
		<script src="js/jquery.maskedinput.js" type="text/javascript"></script>
		<script>
$("document").ready(function(){

});
			
			
jQuery(function($){
   $("#date").mask("9 9 9 9 9 9 9 9 9 9 9 9 9 9 9",{placeholder:"_______________"});
});			
		</script>			
	</head>
<body>
<input name="Text1" id="date" type="text" style="width: 330px" />

</body>
</html>